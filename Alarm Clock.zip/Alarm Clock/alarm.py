import datetime
import time

hour = int(input("What hour do you want to wake up?"))
minute = int(input("What minute do you want to wake up?"))
ampm = str(input("Am or Pm"))
snooze = int(input("In seconds, indicate how long the alarm should snooze."))

if(ampm == "pm"):
    hour = hour + 12

while(1 == 1):
    if(hour == datetime.datetime.now().hour and
       minute == datetime.datetime.now().minute):
        print("Wake up")
        for i in range(snooze):
            print(str(snooze - i) + " seconds remaining")
            time.sleep(1)
        print('Wake up')
        break


print("Exited")
